﻿param()
$ErrorActionPreference="Continue"
$RUNTAG="g-roll-g2-pose-seamless"
. "$PSScriptRoot\fm-lib.ps1"
$N_CONTINUE_EXPECT=B64 "57un57ut5a+55bGA"
if($N_CONTINUE -ne $N_CONTINUE_EXPECT){ throw "N_CONTINUE must stay 继续对局" }

$rt="C:\Users\ZYDN\Documents\Codex\2026-10-26\windows-hayo-pc-https-github-com\work\hayo-pc-6c6b0b0-win-runtime"
$exeRelease=Join-Path $rt "clients\pc\src\FindTeammates.App\bin\x64\Release\net8.0-windows10.0.19041.0\win-x64\FindTeammates.App.exe"
$shotDir=Join-Path $rt "shots-g-roll-g2-pose-seamless-6c6b0b0"
New-Item -ItemType Directory -Force -Path $shotDir | Out-Null
$summary=Join-Path $shotDir "launch-console-g-roll-g2-pose-seamless.txt"
"" | Set-Content $summary -Encoding UTF8
$PREFIX="phase1-pc-wave7-batch1-g-roll-g2-pose-seamless-6c6b0b0"
$EXE_BIND_SHA="7B6B6B1B3E36F7BFC19E91AD77E30204C2AAE281976ED75D088E3EDB3E6BDB2E"
$TIP_EXPECT="6c6b0b07d6e2a4febbff4b4e6430df11b52ebc65"
$PARENT_EXPECT="9fb9c5b3d2b9890677df549c3f15083452356dda"
$SIZE_EXPECT=272384

$ffmpeg=(Get-Command ffmpeg -ErrorAction SilentlyContinue).Source
if(-not $ffmpeg){ $ffmpeg="C:\Users\ZYDN\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe" }

$N_MY=B64 "6L2u5Yiw5L2g5Ye755CD"
$N_RELEASE=B64 "5p2+5omL5Ye65p2G"
$N_CONTINUE_PULL=B64 "57un57ut5ouJ5p2G"
$N_DRAGCUE=B64 "5ouW5Yqo5q+N55CD"
$N_MOTION=B64 "6L+Q5Yqo"
$N_SLIDE=B64 "5ruR"; $N_ROLL=B64 "5rua"; $N_REST=B64 "5YGc"

function S($n){ ShotQuiet "$PREFIX-$n" | Out-Null }
function Turn { TextOf "TurnPillText" }
function Is-MyTurn { $t=Turn; return ($t -eq $N_MY -or ($t -and $t.StartsWith($N_MY))) }
function Wait-My([int]$sec=55){ $d=(Get-Date).AddSeconds($sec); while((Get-Date) -lt $d){ if(Is-MyTurn){return $true}; if(Has-Settlement){return $false}; Start-Sleep -m 400 }; return $false }
function Wait-NotMy([int]$sec=50){ $d=(Get-Date).AddSeconds($sec); while((Get-Date) -lt $d){ if(-not (Is-MyTurn)){return $true}; if(Has-Settlement){return $false}; Start-Sleep -m 350 }; return $false }
function Parse-Pct([string]$r){ $m=[regex]::Match($r,'本杆\s*(\d+)\s*%'); if($m.Success){return [int]$m.Groups[1].Value}; -1 }
function Parse-Aim([string]$r){ $m=[regex]::Match($r,'瞄准\s*(-?\d+)\s*°'); if($m.Success){return [int]$m.Groups[1].Value}; -999 }
function Fired-Now { $hint=TextOf "HintText"; $phase=TextOf "PhaseHud"; return ($hint.Contains($N_MOTION) -or $phase.Contains("sliding") -or $phase.Contains($N_SLIDE) -or $phase.Contains("rolling") -or $phase.Contains($N_ROLL)) }
function Settle { Start-Sleep -m 300; $null=Wait-Rest 28; Start-Sleep -m 500; if((TextOf "ShotReadout").Contains($N_DRAGCUE)){ Click-Id "PlaceCueBtn" | Out-Null; Start-Sleep 1 } }
function Inj-Down($x,$y){ [void][W32b3]::SetForegroundWindow([IntPtr](Get-AppProc).MainWindowHandle); [W32b3]::AbsMove([int]$x,[int]$y); Start-Sleep -m 40; [W32b3]::LeftDown() }
function Inj-Move($x,$y){ [W32b3]::AbsMove([int]$x,[int]$y) }
function Inj-Up { [W32b3]::LeftUp() }
function Bump-PowerMax {
  $pr=ById "PowerRail"; if(-not $pr){ return }
  $rr=$pr.Current.BoundingRectangle
  $x=[int]($rr.X+$rr.Width/2); $y0=[int]($rr.Y+$rr.Height*0.82); $y1=[int]($rr.Y+$rr.Height*0.10)
  Inj-Down $x $y0; for($i=1;$i -le 18;$i++){ Inj-Move $x ([int]($y0+($y1-$y0)*$i/18.0)); Start-Sleep -m 22 }; Inj-Up; Start-Sleep -m 250
}
function Set-HitCenter {
  $p=ById "HitPad"; if(-not $p){ return }
  $r=$p.Current.BoundingRectangle
  Inj-Down ([int]($r.X+$r.Width/2)) ([int]($r.Y+$r.Height/2)); Start-Sleep -m 60; Inj-Up; Start-Sleep -m 200
}
function Soft-Refresh-Visual {
  $hwnd=[IntPtr](Get-AppProc).MainWindowHandle
  $wr=New-Object W32b3+R; [void][W32b3]::GetWindowRect($hwnd,[ref]$wr)
  $w=$wr.Right-$wr.L; $h=$wr.B-$wr.T
  [void][W32b3]::MoveWindow($hwnd,$wr.L,$wr.T,[Math]::Max(800,$w-40),[Math]::Max(600,$h-30),$true)
  Start-Sleep -m 350; Resize-Default | Out-Null; Start-Sleep -m 500
  [void][W32b3]::SetForegroundWindow($hwnd)
}
function Exit-And-Rematch {
  Leave-Settlement-IfAny
  if(Has-Settlement){ Leave-Settlement-IfAny }
  $null=Trigger-ExitBtn; Start-Sleep 1
  if(Wait-UI16 5){ Click-ConfirmExit | Out-Null; Start-Sleep 2 }
  else { Trigger-NavBack | Out-Null; Start-Sleep 1; if(Wait-UI16 4){ Click-ConfirmExit | Out-Null; Start-Sleep 2 } }
  $deadline=(Get-Date).AddSeconds(20)
  while((Get-Date) -lt $deadline){ if(On-Plaza -or (Find-Contains (Get-AppRoot) $N_GAMES)){ break }; if(Has-Settlement){ Leave-Settlement-IfAny }; Start-Sleep -m 500 }
  Start-Sleep 1
  if(-not (Go-Games-Match)){ return $false }
  Start-Sleep 1; Resize-Default | Out-Null
  if(-not (Is-MyTurn)){ $null=Wait-My 50 }
  Bump-PowerMax
  return (Is-MyTurn)
}
function Try-PullShot([string]$tag,[int]$aimDx,[int]$aimDy,[int]$pullPx){
  Resize-Default | Out-Null; Set-HitCenter
  $idle=ShotQuiet "$PREFIX-$tag-pre"; $wb=Find-White $idle
  if($wb.S -lt 20){ return @{Ok=$false; Why='no_wb'} }
  Inj-Down ([int]($wb.SX+$aimDx)) ([int]($wb.SY+$aimDy)); Start-Sleep -m 70; Inj-Up; Start-Sleep -m 280
  $aimDeg=Parse-Aim (TextOf "ShotReadout"); S "$tag-aimed"
  $idle2=ShotQuiet "$PREFIX-$tag-aimed2"; $wb2=Find-White $idle2; if($wb2.S -ge 20){ $wb=$wb2; $idle=$idle2 }
  $bc=Find-Brown $idle $wb; $o=Win-Origin
  $len=[Math]::Sqrt($aimDx*$aimDx+$aimDy*$aimDy); if($len -lt 1){ $len=1 }
  $ux=$aimDx/$len; $uy=$aimDy/$len
  $cands=@(); if($bc.S -gt 20){ $cands += @{X=$bc.X;Y=$bc.Y} }
  $cands += @{X=[int]($wb.X - [Math]::Round(70*$ux)); Y=[int]($wb.Y - [Math]::Round(70*$uy))}
  $cands += @{X=[int]($wb.X - [Math]::Round(100*$ux)); Y=[int]($wb.Y - [Math]::Round(100*$uy))}
  $cands += @{X=[int]($wb.X-70); Y=[int]$wb.Y}
  $cands += @{X=[int]($wb.X-100); Y=[int]$wb.Y}
  $cands += @{X=[int]($wb.X-130); Y=[int]$wb.Y}
  foreach($c in $cands){
    $sx=$c.X+$o.L; $sy=$c.Y+$o.T
    $px=[int]($sx - $ux*$pullPx); $py=[int]($sy - $uy*$pullPx)
    Log "$tag TRY scr=$sx,$sy to=$px,$py pull=$pullPx"
    Inj-Down $sx $sy; Start-Sleep -m 100
    for($i=1;$i -le 22;$i++){ Inj-Move ([int]($sx+($px-$sx)*$i/22.0)) ([int]($sy+($py-$sy)*$i/22.0)); Start-Sleep -m 28 }
    Start-Sleep -m 280
    $r=TextOf "ShotReadout"; $pct=Parse-Pct $r; $ad=Parse-Aim $r; if($ad -eq -999){ $ad=$aimDeg }
    Log "$tag HOLD readout=$r pct=$pct"
    if($r.Contains($N_RELEASE) -or $r.Contains($N_CONTINUE_PULL)){
      if($r.Contains($N_CONTINUE_PULL) -and -not $r.Contains($N_RELEASE)){
        $px2=[int]($sx - $ux*($pullPx+50)); $py2=[int]($sy - $uy*($pullPx+50))
        for($i=1;$i -le 10;$i++){ Inj-Move ([int]($px+($px2-$px)*$i/10.0)) ([int]($py+($py2-$py)*$i/10.0)); Start-Sleep -m 28 }
        Start-Sleep -m 200; $r=TextOf "ShotReadout"; $pct=Parse-Pct $r
      }
      if($r.Contains($N_RELEASE)){
        S "$tag-pull"
        return @{Ok=$true; Readout=$r; Pct=$pct; Aim=$ad; SX=$sx; SY=$sy; PX=$px; PY=$py; Hit=(TextOf "HitPointText"); WB0=$wb}
      }
    }
    Inj-Up; Start-Sleep -m 220
  }
  return @{Ok=$false; Readout=(TextOf "ShotReadout"); Pct=-1}
}
function Calibrate-Pull([string]$tag,[int]$aimDx,[int]$aimDy,[int]$lo,[int]$hi,[int[]]$pulls){
  foreach($p in $pulls){
    if(-not (Is-MyTurn)){ $null=Wait-My 40 }
    $h=Try-PullShot $tag $aimDx $aimDy $p
    if($h.Ok){
      Log "$tag CAL pull=$p pct=$($h.Pct)"
      if($h.Pct -ge $lo -and $h.Pct -le $hi){ return $h }
      if($h.Pct -ge ($lo-15) -and $h.Pct -le ($hi+10)){ return $h }
      for($i=1;$i -le 16;$i++){ Inj-Move ([int]($h.PX+($h.SX-$h.PX)*$i/16.0)) ([int]($h.PY+($h.SY-$h.PY)*$i/16.0)); Start-Sleep -m 24 }
      Start-Sleep -m 150; Inj-Up; Start-Sleep -m 300
    } else { Log "$tag CAL_MISS pull=$p readout=$($h.Readout)" }
  }
  return (Try-PullShot $tag $aimDx $aimDy $pulls[[int]($pulls.Count/2)])
}
function Get-WinCaptureRect {
  $hwnd=[IntPtr](Get-AppProc).MainWindowHandle
  $wr=New-Object W32b3+R; [void][W32b3]::GetWindowRect($hwnd,[ref]$wr)
  $x=[Math]::Max(0,$wr.L); $y=[Math]::Max(0,$wr.T)
  $w=$wr.Right-$wr.L; $h=$wr.B-$wr.T
  if($w % 2 -ne 0){ $w-- }; if($h % 2 -ne 0){ $h-- }
  return @{X=$x;Y=$y;W=$w;H=$h}
}
function Start-GdiGrab([string]$outMp4,[int]$secs=90){
  [void][W32b3]::SetForegroundWindow([IntPtr](Get-AppProc).MainWindowHandle)
  Start-Sleep -m 200
  $rc=Get-WinCaptureRect
  if(Test-Path $outMp4){ Remove-Item $outMp4 -Force }
  $ffArgs=@("-y","-f","gdigrab","-framerate","30","-offset_x","$($rc.X)","-offset_y","$($rc.Y)","-video_size","$($rc.W)x$($rc.H)","-i","desktop","-t","$secs","-c:v","libx264","-pix_fmt","yuv420p","-preset","veryfast","-crf","23",$outMp4)
  Log ("FFMPEG_START secs=$secs out=$outMp4 rect=$($rc.X),$($rc.Y) $($rc.W)x$($rc.H)")
  $err=Join-Path $shotDir ("ffmpeg-" + [IO.Path]::GetFileNameWithoutExtension($outMp4) + ".err.txt")
  $out=Join-Path $shotDir ("ffmpeg-" + [IO.Path]::GetFileNameWithoutExtension($outMp4) + ".out.txt")
  $proc=Start-Process -FilePath $ffmpeg -ArgumentList $ffArgs -PassThru -WindowStyle Hidden -RedirectStandardError $err -RedirectStandardOutput $out
  Start-Sleep -m 900
  return @{Proc=$proc; Out=$outMp4; Err=$err; StartedAt=(Get-Date); Secs=$secs; Rect=$rc}
}
function Stop-GdiGrab($rec,[int]$maxWaitSec=110){
  if(-not $rec -or -not $rec.Proc){ return $null }
  $deadline=(Get-Date).AddSeconds($maxWaitSec)
  while(-not $rec.Proc.HasExited -and (Get-Date) -lt $deadline){ Start-Sleep -m 400 }
  if(-not $rec.Proc.HasExited){ try{$rec.Proc.CloseMainWindow()|Out-Null}catch{}; Start-Sleep 1; if(-not $rec.Proc.HasExited){ Stop-Process -Id $rec.Proc.Id -Force -ea 0 } }
  Start-Sleep -m 500
  if(Test-Path $rec.Out){ $sha=(Get-FileHash $rec.Out -Algorithm SHA256).Hash; $sz=(Get-Item $rec.Out).Length; Log ("FFMPEG_OUT size=$sz sha=$sha"); return @{Size=$sz;Sha=$sha;Path=$rec.Out} }
  return $null
}
function Observe-Motion([string]$tag,$wb0,[int]$motionShots=6){
  $fired=$false; $maxDist=0; $phases=@()
  for($k=0;$k -lt $motionShots;$k++){
    Start-Sleep -m 320
    $phase=TextOf "PhaseHud"; $phases += $phase
    Log "$tag MOTION_$k phase=$phase hint=$(TextOf 'HintText')"
    $mp=ShotQuiet "$PREFIX-$tag-motion$k"
    if($mp -and $wb0){ $wbm=Find-White $mp; if($wbm.S -ge 15){ $dx=[int]($wbm.X-$wb0.X); $dy=[int]($wbm.Y-$wb0.Y); $dist=[int][Math]::Sqrt($dx*$dx+$dy*$dy); if($dist -gt $maxDist){$maxDist=$dist}; Log "$tag WB_MOTION_$k dist=$dist" } }
    if(Fired-Now){ $fired=$true }
  }
  return @{Fired=$fired; MaxWbDist=$maxDist; Phases=$phases}
}

# ===== PRE-BIND =====
Push-Location $rt
$tip=(git rev-parse HEAD).Trim()
$parent=(git rev-parse HEAD^).Trim()
Pop-Location
$exeItem=Get-Item $exeRelease
$exeHash=(Get-FileHash $exeRelease -Algorithm SHA256).Hash
$exeSize=$exeItem.Length
$exeMtime=$exeItem.LastWriteTime.ToString("yyyy-MM-ddTHH:mm:sszzz")
$banDD=$exeHash.StartsWith("DD02432A")
$banADA=$exeHash.StartsWith("ADAEB7F8")
$banTip=($tip.StartsWith("5d6987f"))
$bindMatch=(($tip -eq $TIP_EXPECT) -and ($parent -eq $PARENT_EXPECT) -and ($exeHash -eq $EXE_BIND_SHA) -and ($exeSize -eq $SIZE_EXPECT) -and (-not $banDD) -and (-not $banADA) -and (-not $banTip))
$bindPath=Join-Path $shotDir "exe-bind-6c6b0b0-g2.txt"
@(
  "tip=$tip",
  "parent=$parent",
  "exe=$exeRelease",
  "size=$exeSize",
  "sha256=$exeHash",
  "mtime=$exeMtime",
  "ban_DD02432A=$banDD",
  "ban_ADAEB7F8=$banADA",
  "ban_tip_5d6987f=$banTip",
  "client=1650x1080",
  "dpi=144",
  "BIND_MATCH=$bindMatch",
  "pack=g2-pose-seamless",
  "recorded_at=$((Get-Date).ToString('yyyy-MM-ddTHH:mm:sszzz'))"
) | Set-Content $bindPath -Encoding UTF8
Log "BIND tip=$tip parent=$parent sha=$exeHash size=$exeSize mtime=$exeMtime MATCH=$bindMatch"
if(-not $bindMatch){ Log "BIND_BLOCK abort"; Kill-App; exit 12 }

$env:FINDTEAMMATES_BILLIARDS_HOTSEAT="1"; $env:FINDTEAMMATES_API_MODE="mock"

function Run-G2-Once([string]$attemptTag){
  Log "=== G2 ATTEMPT $attemptTag ==="
  $mp4Name="g-roll-g2-pose-seamless-6c6b0b0.mp4"
  $mp4Path=Join-Path $shotDir $mp4Name

  # Calibrate seed WITHOUT recording
  Log "=== G2: calibrate seed (no record yet) ==="
  if(-not (Is-MyTurn)){ $null=Wait-My 50 }
  Bump-PowerMax
  $seedH=Calibrate-Pull "g2seed" 250 -10 70 95 @(220,240,260,280,300,200,320)
  if(-not $seedH.Ok){
    Log "SEED_HOLD_FAIL"
    return @{Ok=$false; Why='seed_hold_fail'}
  }
  Log ("SEED_HOLD_READY pct=$($seedH.Pct) aim=$($seedH.Aim) readout=$($seedH.Readout)")

  # Start ONE continuous gdigrab BEFORE seed release
  $recSecs=140
  $rec=Start-GdiGrab $mp4Path $recSecs
  if(-not $rec.Proc -or $rec.Proc.HasExited){
    Log "FFMPEG_START_FAIL"
    try{ Inj-Up }catch{}
    return @{Ok=$false; Why='ffmpeg_start_fail'}
  }
  Start-Sleep -m 400
  Log "CHAIN_T0 seed Inj-Up (record running)"
  $tSeedFire=Get-Date
  Inj-Up
  Start-Sleep -m 220
  $seedObs=Observe-Motion "g2seed" $seedH.WB0 8
  $seedFired=$seedObs.Fired
  # Wait balls stop
  $sw=[Diagnostics.Stopwatch]::StartNew()
  while($sw.Elapsed.TotalSeconds -lt 18){
    $phase=TextOf "PhaseHud"; $r=TextOf "ShotReadout"
    if((Has-Settlement) -or $r.Contains($N_DRAGCUE) -or (-not (Fired-Now) -and $sw.Elapsed.TotalSeconds -gt 1.0 -and ($phase -match 'rest' -or $phase.Contains($N_REST)))){ break }
    Start-Sleep -m 280
  }
  $null=Wait-Rest 20
  S "g2-post-stop"
  $preStopTurn=Turn
  $tPostStop=Get-Date
  Log ("POST_STOP turn=$preStopTurn seedFired=$seedFired pct=$($seedH.Pct) elapsed_s=$([int]($tPostStop-$tSeedFire).TotalSeconds)")

  # Handoff wait (still in same record)
  $handed=$false
  if(-not (Is-MyTurn)){ $handed=$true } else { $handed=Wait-NotMy 45 }
  # If still my turn after seed (kept turn), treat as pose handoff candidate via Soft-Refresh
  if(-not $handed -and (Is-MyTurn)){
    Log "NO_TURN_FLIP_AFTER_SEED — still my turn; continue as same-seat handoff/pose path"
  }
  Soft-Refresh-Visual
  S "g2-after-handoff"
  $afterHandTurn=Turn
  $tHandoff=Get-Date
  Log ("AFTER_HANDOFF handed=$handed turn=$afterHandTurn elapsed_s=$([int]($tHandoff-$tSeedFire).TotalSeconds)")

  # Wait until my turn again if needed
  if(-not (Is-MyTurn)){
    $got=Wait-My 50
    Log "WAIT_MY_AGAIN got=$got turn=$(Turn)"
  }
  S "g2-before-next"
  Soft-Refresh-Visual
  Bump-PowerMax

  $nextFired=$false; $nextPct=-1; $nextAim=-999; $nextNote="skip"; $nextObs=$null
  if(Is-MyTurn){
    # Calibrate next pull WHILE record still running (different aim ok)
    $nxH=Calibrate-Pull "g2next" 180 -60 25 70 @(140,160,180,200,220,120,240,100,260,80)
    if(-not $nxH.Ok){
      Log "NEXT_RETRY horizontal"
      $nxH=Calibrate-Pull "g2nextb" 250 -10 40 90 @(200,220,240,260,180,280)
    }
    if($nxH.Ok){
      Log ("NEXT_HOLD_READY pct=$($nxH.Pct) aim=$($nxH.Aim)")
      $tNextFire=Get-Date
      Inj-Up
      Start-Sleep -m 220
      $nextObs=Observe-Motion "g2next" $nxH.WB0 8
      $nextFired=$nextObs.Fired
      $nextPct=$nxH.Pct
      $nextAim=$nxH.Aim
      $sw2=[Diagnostics.Stopwatch]::StartNew()
      while($sw2.Elapsed.TotalSeconds -lt 14){
        $phase=TextOf "PhaseHud"; $r=TextOf "ShotReadout"
        if((Has-Settlement) -or $r.Contains($N_DRAGCUE) -or (-not (Fired-Now) -and $sw2.Elapsed.TotalSeconds -gt 1.0 -and ($phase -match 'rest' -or $phase.Contains($N_REST)))){ break }
        Start-Sleep -m 280
      }
      S "g2-next-end"
      $nextNote=("pct=$nextPct aim=$nextAim fired=$nextFired maxWbDist=$($nextObs.MaxWbDist) phases=$([string]::Join('>',@($nextObs.Phases))) t_from_seed_s=$([int]($tNextFire-$tSeedFire).TotalSeconds)")
      Log "NEXT $nextNote"
    } else {
      $nextNote="hold_fail_after_retries"
      Log "NEXT_HOLD_FAIL"
      # release any stuck mouse
      try{ Inj-Up }catch{}
    }
  } else {
    $nextNote="not_my_turn_skip"
    Log "NEXT_SKIP not my turn"
  }
  S "g2-after-next"

  # Wait out remaining gdigrab (must be single continuous session)
  $elapsedRec=[int]((Get-Date)-$rec.StartedAt).TotalSeconds
  $remain=[Math]::Max(2, $rec.Secs - $elapsedRec + 2)
  Log "WAIT_OUT_GDIGRAB elapsed=$elapsedRec remain~$remain"
  $ff=Stop-GdiGrab $rec ([Math]::Max(20,$remain+5))

  $chainOk=($seedFired -and $nextFired -and $ff -and $ff.Size -gt 100000)
  return @{
    Ok=$chainOk
    SeedFired=$seedFired
    SeedPct=$seedH.Pct
    SeedAim=$seedH.Aim
    Handed=$handed
    PostStopTurn=$preStopTurn
    AfterHandTurn=$afterHandTurn
    NextFired=$nextFired
    NextPct=$nextPct
    NextAim=$nextAim
    NextNote=$nextNote
    Ff=$ff
    Mp4=$mp4Path
    Why=$(if($chainOk){'ok'}else{"seedFired=$seedFired nextFired=$nextFired ff=$([bool]$ff)"})
  }
}

$entered=$false
for($attempt=1; $attempt -le 4; $attempt++){
  Log "ENTER_ATTEMPT=$attempt"
  Kill-App; Start-Sleep 2
  if(-not (Start-App $exeRelease ("g2-"+$attempt))){ Log "START_FAIL"; Start-Sleep 2; continue }
  Start-Sleep 3
  if(Ensure-In-Match){ $entered=$true; break }
  Log "ENTER_FAIL attempt=$attempt"
  Kill-App; Start-Sleep 2
}
if(-not $entered){ Log "ENTER_FAIL_ALL"; exit 3 }
Resize-Default | Out-Null
if(-not (Is-MyTurn)){ $null=Wait-My 50 }
Bump-PowerMax

$result=Run-G2-Once "1"
if(-not $result.Ok){
  Log "G2_ATTEMPT1_FAIL why=$($result.Why) — rematch once and retry"
  # ensure mouse up / stop any leftover ffmpeg
  try{ Inj-Up }catch{}
  Get-Process ffmpeg -ea 0 | ForEach-Object { Stop-Process $_.Id -Force -ea 0 }
  $rm=Exit-And-Rematch
  Log "REMATCH_OK=$rm"
  if($rm){
    S "g2-rematch-ready"
    $result=Run-G2-Once "2"
  } else {
    Log "REMATCH_FAIL — cannot retry"
  }
}

$verdictPath=Join-Path $shotDir "verdict-g-roll-g2-pose-seamless.txt"
$label=$(if($result.Ok){'通过'}else{'失败'})
$ffSha=$(if($result.Ff){$result.Ff.Sha}else{'none'})
$ffSz=$(if($result.Ff){$result.Ff.Size}else{0})
$line=("G2_POSE_SEAMLESS|{0}|seedFired={1} seedPct={2} seedAim={3} handed={4} postStop={5} afterHand={6} nextFired={7} nextPct={8} nextAim={9} nextNote={10} mp4sha={11} mp4size={12} demo_ne_pass=True VERIFY_COMPLETE_NE_PRODUCT_PASS=True G_ROLL_OPEN=True" -f $label,$result.SeedFired,$result.SeedPct,$result.SeedAim,$result.Handed,$result.PostStopTurn,$result.AfterHandTurn,$result.NextFired,$result.NextPct,$result.NextAim,$result.NextNote,$ffSha,$ffSz)
$line | Set-Content $verdictPath -Encoding UTF8
Log $line
Log "=== G2 POSE SEAMLESS DONE ==="
Kill-App
# kill leftover ffmpeg if any
Get-Process ffmpeg -ea 0 | ForEach-Object { Stop-Process $_.Id -Force -ea 0 }
exit $(if($result.Ok){0}else{5})
